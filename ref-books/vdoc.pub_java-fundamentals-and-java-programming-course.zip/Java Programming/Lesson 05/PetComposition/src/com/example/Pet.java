package com.example;

interface Pet {

    public String getName();

    public void setName(String name);

    public void play();
    
}