 
public class QuotationTest {


    public static void main (String args[]) {

      Quotation myQuotation = new Quotation();
    
      myQuotation.display();
    }
}
