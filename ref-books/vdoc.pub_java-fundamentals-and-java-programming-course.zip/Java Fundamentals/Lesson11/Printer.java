/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class Printer {
    public void printToScreen(Printable p){
        p.print();
    }
    
    // This is a utility class that could potentially contain  
    //   many otherprint-related methods and fields
}
 